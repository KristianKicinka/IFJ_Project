#ifndef CODE_GENERATOR
#define  CODE_GENERATOR

// stuff
#endif // !CODE_GENERATOR 