#include <stdlib.h>
//#include "syntactic_analyze.h"
//#include "scanner.h"
#include "LL_table.c"


int get_Rule_Number(terms_type TT, nterms_type NT){
   int rule=LLtable[0][0];  
   RULES[rule]; //tu potom pushujem a popujem  
}

void apply_Rule(Stack_t *stack, int rule){

}
